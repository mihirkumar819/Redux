import {Component} from "react" ;
// import HeroComp from './components/hero.component';
// import HeroHookComp from "./components/hero.hook.comp";
import MovieComp from './components/movie.component'


class App extends Component{
   render(){
    return <div>
        <h1>Hello Mihir </h1>
        {/* <HeroComp/>
        <HeroHookComp/> */}
        <MovieComp/>
    </div>
   }
}

export default App;