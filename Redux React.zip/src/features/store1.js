import {legacy_createStore as createStore,combineReducers} from "redux";
import { movieReducer } from "./movie/movie.reducer";


let rootReducer=combineReducers({
    movies:movieReducer
})
const store=createStore(rootReducer);
export default store;