import {legacy_createStore as createStore,combineReducers} from "redux";
import { heroReducer } from "./hero/hero.reducer";


let rootReducer=combineReducers({
    heroes:heroReducer
})
const store=createStore(rootReducer);
export default store;