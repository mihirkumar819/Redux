import { ADD_MOVIE, REMOVE_MOVIE } from "./movie.type"

const addmovie=()=>{
    return {
        type:ADD_MOVIE
    }
}
const removemovie=()=>{
    return {
        type:REMOVE_MOVIE
    }
}
export {addmovie,removemovie};