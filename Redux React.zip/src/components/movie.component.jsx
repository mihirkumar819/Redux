import {Component} from "react";
import { connect } from "react-redux";
import {addmovie,removemovie} from "../redux/index1"
class MovieComp extends Component{
    render(){
        return <div>
            <h2>Movie Component</h2>
            <h3> Total Movie Component :{this.props.numOfMovies}</h3>

            <button onClick={this.props.addMovie}>ADD Movie</button>
            <button onClick={this.props.removeMovie}>REMOVE Movie</button>

        </div>
    }
}

const mapStateToProps = (state)=>{
    return{
        numOfMovies:state.movies.numOfMovies
    }
}
const mapDispatchProps=(dispatch)=>{
    return {
        addMovie:()=>dispatch( addmovie()),
        removeMovie:()=>dispatch(removemovie())
    }
}

export default connect(mapStateToProps,mapDispatchProps)( MovieComp);