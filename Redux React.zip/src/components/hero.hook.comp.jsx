import { useDispatch,useSelector } from "react-redux";
import {addhero,removehero} from "../redux/index";
let HeroHookComp=()=>{
    const numOfHeroesHook=useSelector(state=>state.heroes.numOfHeroes);
    const dispatch=useDispatch();
    return <div>
    <h2>Hero Hook Component</h2>
    <h3> Total Hero Component :{numOfHeroesHook}</h3>

    <button onClick={()=>dispatch(addhero())}>ADD Hero</button>
    <button onClick={()=>dispatch(removehero())}>REMOVE Hero</button>

</div>
}

export default HeroHookComp ;