import {Component} from "react";
import { connect } from "react-redux";
import {addhero,removehero} from "../redux/index"
class HeroComp extends Component{
    render(){
        return <div>
            <h2>Hero Component</h2>
            <h3> Total Hero Component :{this.props.numOfHeroes}</h3>

            <button onClick={this.props.addHero}>ADD Hero</button>
            <button onClick={this.props.removeHero}>REMOVE Hero</button>

        </div>
    }
}

const mapStateToProps = (state)=>{
    return{
        numOfHeroes:state.heroes.numOfHeroes
    }
}
const mapDispatchProps=(dispatch)=>{
    return {
        addHero:()=>dispatch( addhero()),
        removeHero:()=>dispatch(removehero())
    }
}

export default connect(mapStateToProps,mapDispatchProps)( HeroComp);