let redux = require("redux");
// const { default: thunk } = require("redux-thunk");
// let reduxThunk = require("redux-thunk").default;
let createStore = redux.legacy_createStore;
// let applyMiddleware = redux.applyMiddleware;
//let compose=redux.compose;
//const logger=require("redux-logger").createLogger;

//let axios = require("axios");
let process =require("process")
 
// action type is a constant name
const AXIOS_USERS_REQUEST = "AXIOS_USERS_REQUEST";
const AXIOS_USERS_SUCCESS = "AXIOS_USERS_SUCCESS";
const AXIOS_USERS_ERROR = "AXIOS_USERS_ERROR";
 
// action creator is function that returns an action object 
let fetchUsers = (users) => {
    return {
        type : AXIOS_USERS_REQUEST,
        payload:users
    }
}
let fetchUserSuccess = (users1) => {
    return {
        type : AXIOS_USERS_SUCCESS,
        payload : users1
    }
}
// let fetchUserError = (error) => {
//     return {
//         type : AXIOS_USERS_ERROR,
//         payload : error
//     }
// }
// intial state is intial value of store object
const intialState = {
    title:'',
    name:"",
    power:""

}
 
// reducer is a function which has switch cases to call functions based on action type
const reducer = (state = intialState, action)=>{
    switch(action.type){
        case AXIOS_USERS_REQUEST : return {     ...state,
                                                title : action.payload,
                                                name : "",
                                                power : 0
                                            }
        case AXIOS_USERS_SUCCESS : return {     ...state,
                                            title :"",
                                            name : " action.payload",
                                            power : 0
                                            }
        // case AXIOS_USERS_ERROR : return {   ...state,
        //                                         loading : false,
        //                                         error : action.payload,
        //                                         users : [] 
        //                                     }
        default : return state
        
    }
};
 

let store=createStore(reducer);
store.subscribe( ()=>{
    console.log( store.getState() );
})

store.dispatch(fetchUsers(process.argv[1]));
store.dispatch(fetchUserSuccess (process.argv[2]));
