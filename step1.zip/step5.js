//action  type is a constant name 
//action creator is function that returns an action object
// reducer is a function which has switch cases to call function based on action type
//initial state is initial value of storeobject
// store is an object that stores all shared states of your application
// subscribe /unsubscrbe to listen to change of the store
//dispatch is a method that can take action object


let redux=require("redux");
let createStore =redux.legacy_createStore;
let combineReducers=redux.combineReducers;
let bindActionCreators=redux.bindActionCreators;

const ADDHERO="ADDHERO";
const REMOVEHERO="REMOVEHERO";
const SETHERO="SETHERO";
const ADDMOVIE="ADDMOVIE";
const REMOVEMOVIE="REMOVEMOVIE";
const SETMOVIE="SETMOVIE"



let addhero=function(){
    return{
    type:ADDHERO
    }
};
let removehero=function(){
    return{
    type:REMOVEHERO
    }
};
let sethero=(num)=>{
    return{
    type:SETHERO,
    payload:num
    }
};
let addmovie=function(){
    return{
    type:ADDMOVIE
    }
};
let removemovie=function(){
    return{
    type:REMOVEMOVIE
    }
};
let setmovie=(num)=>{
    return{
    type:SETMOVIE,
    payload:num
    }
};



let initialHeroState={
    numberOfHeroes:0
}


let initialMovieState={
    numberOfMovies:0
}


let heroreducer=(state=initialHeroState,action)=>{
    switch(action.type){
        case ADDHERO:return {numberOfHeroes:state.numberOfHeroes +10}
        case REMOVEHERO:return {numberOfHeroes:state.numberOfHeroes -5}
        case SETHERO:return {numberOfHeroes:action.payload}
        default : return state
    }
};
let moviereducer=(state=initialMovieState,action)=>{
    switch(action.type){
        case ADDMOVIE:return {numberOfMovies:state.numberOfMovies +10}
        case REMOVEMOVIE:return {numberOfMovies:state.numberOfMovies -5}
        case SETMOVIE:return {numberOfMovies:action.payload}
        default : return state
    }
};

 rootReducers=combineReducers({
    heroes:heroreducer,
    movies:moviereducer

})
let store=createStore(rootReducers);
console.log("Initial  value of stores",store.getState());

// let unsubscribe=store.subscribe(()=>console.log("subscibed", store.getState().heroes));  return only Heroes property
let unsubscribe=store.subscribe(()=>console.log("subscibed", store.getState()));
console.log(store.getState());
let action=bindActionCreators({addhero,removehero,sethero,addmovie,removemovie,setmovie},store.dispatch);
action.addhero();
action.removehero();
action.sethero(1000);
action.setmovie(2525);
action.addmovie();
action.removemovie();





// store.dispatch(addhero());
// store.dispatch(addhero());
// store.dispatch(removehero());
// store.dispatch(addhero());
// store.dispatch(removehero());
// store.dispatch(sethero(500));
// store.dispatch(addhero());
// store.dispatch(removehero());

// store.dispatch(addmovie());
// store.dispatch(addmovie());
// store.dispatch(removemovie());
// store.dispatch(addmovie());
// store.dispatch(removemovie());
// store.dispatch(setmovie(500));
// store.dispatch(addmovie());
// store.dispatch(removemovie());




