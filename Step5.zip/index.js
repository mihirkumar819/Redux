const store=require("./app/store");
const fetchUsers=require("./app/features/users/userSlice").fetchUsers;
console.log("Initial State",store.getState());
store.subscribe(()=>{});
store.dispatch(fetchUsers());

// unsubscribe();