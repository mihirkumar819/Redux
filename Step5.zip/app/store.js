const configureStore=require("@reduxjs/toolkit").configureStore;
const userReducer=require("../app/features/users/userSlice");
const logger=require("redux-logger").createLogger;

const store=configureStore({
    reducer:{
      user:userReducer
    },
    middleware:(getDefaultMiddleware)=>getDefaultMiddleware().concat(logger())
});
module.exports=store;