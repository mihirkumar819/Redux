import {Component} from "react" ;
import HeroView from './features/hero/heroView'
import MovieView from "./features/movie/movieView";



class App extends Component{
   render(){
    return <div>
        <h1>Hello Mihir </h1>
        <HeroView/>
        
        <MovieView/>
    </div>
   }
}

export default App;