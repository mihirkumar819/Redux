const store = require("./app/store");
const movieActions = require("./features/movie/movieslice").movieActions;
const heroActions = require("./features/hero/heroslice").heroActions;

 
 console.log("Initial State", store.getState());
 
 
const unsubscribe = store.subscribe(()=>{
    console.log("Updated State", store.getState());
})
 
// store.dispatch(movieActions.addMovie());
// store.dispatch(movieActions.addMovie());
// store.dispatch(movieActions.removeMovie());
// store.dispatch(movieActions.addMovie());
// store.dispatch(movieActions.addMovie());
// store.dispatch(movieActions.setMovie(20200));

store.dispatch(heroActions.addHero());
// store.dispatch(heroActions.setHero(10));

// store.dispatch(heroActions.addHero());
// store.dispatch(heroActions.removeHero());
// store.dispatch(heroActions.addHero());
// store.dispatch(heroActions.addHero());
// store.dispatch(heroActions.removeHero());
 


unsubscribe();




