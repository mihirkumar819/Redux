// const createSlice =require("@reduxjs/toolkit").createSlice;
import { createSlice } from "@reduxjs/toolkit";



const heroSlice=createSlice({
    name:"Hero",
    initialState:initialState,
    reducers:{
        addHero:(state)=>{
            state.numberOfHeroes++
        },
        removeHero:(state)=>{
            state.numberOfHeroes--
        },
        setHero:(state,action)=>{
            state.numberOfHeroes=action.payload
        }
    }
})
export default heroSlice.reducer;
export const {addHero,removeHero,setHero}=heroSlice.action;