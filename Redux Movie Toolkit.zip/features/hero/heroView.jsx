import {Component} from "react";
import {addHero,removeHero} from "../hero/heroslice"
class HeroView extends Component{
    render(){
        return <div>
            
    <button onClick={()=>dispatch(addHero())}>ADD Hero</button>
    <button onClick={()=>dispatch(removeHero())}>REMOVE Hero</button>
        </div>
    }
}
export default HeroView;