import {Component} from "react";
import {addMovie,removeMovie} from "../movie/movieslice"
class MovieView extends Component{
    render(){
        return <div>
             <button onClick={()=>dispatch(addMovie())}>ADD Hero</button>
            <button onClick={()=>dispatch(removeMovie())}>REMOVE Hero</button>
        </div>
    }
}
export default MovieView;