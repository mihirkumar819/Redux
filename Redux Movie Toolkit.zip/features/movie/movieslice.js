import { createSlice } from "@reduxjs/toolkit";

const movieSlice=createSlice({
    name:"Movie",
    initialState:initialState,
    reducers:{
        addMovie:(state)=>{
            state.numberOfMovies++
        },
        removeMovie:(state)=>{
            state.numberOfMovies--
        },
        setMovie:(state,action)=>{
            state.numberOfMovies=action.payload
        },
     

    }
})

export default movieSlice.reducer;
export const {addMovie,removeMovie,setMovie}=movieSlice.actions;



/*****Extra Reducer */
//  extraReducer:{
//     ['hero/addHero']:(state)=>{
//         state.numberOfMovies++
//     }
//  }

   // extraReducer:builder => {
        //     builder.addCase(heroActions.addHero,state=>{
        //         state.numberOfMovies++
        //     })
        // }
