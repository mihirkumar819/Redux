const configureStore=require("@reduxjs/toolkit").configureStore;
const movieReducer=require("../features/movie/movieslice");
const heroReducer=require("../features/hero/heroslice");
// const { getDefaultMiddleware } = require("@reduxjs/toolkit");
const logger=require("redux-logger").createLogger;

const store=configureStore({
    reducer:{
        movie:movieReducer,
        hero:heroReducer
    },
    middleware:(getDefaultMiddleware)=>getDefaultMiddleware().concat(logger())
});
module.exports=store;